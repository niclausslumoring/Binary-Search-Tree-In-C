#include<stdio.h>
#include<stdlib.h>

struct Node{
	int val;
	struct Node *left;
	struct Node *right;
};

struct Node *new_node(int val){
	struct Node *temp = (struct Node*)malloc(sizeof(struct Node));
	
	temp->val = val;
	temp->left = NULL;
	temp->right = NULL;
	
	return temp;
}

struct Node *delete_node(struct Node *root, int val){
	if (root == NULL){
		return NULL;
	}
	else if (val > root->val){
		root->right = delete_node(root->right, val);
	}
	else if (val < root->val){
		root->left = delete_node(root->left, val);
	}
	else if (val == root->val){
		//Node gak punya anak
		if(root->left == NULL && root->right == NULL){
			free(root);
			root = NULL;
		}
		//Node yang punya 1 anak
		//anak kiri
		else if(root->left != NULL && root->right == NULL){
			struct Node *temp = root->left;
			*root = *temp;
			free(temp);
		}
		//anak kanan
		else if(root->left == NULL && root->right != NULL){
			struct Node *temp = root->right;
			*root = *temp;
			free(temp);
		}
		//Node punya 2 anak
		else if(root->left != NULL && root->right != NULL){
			struct Node *temp;
			temp = root->left;
			while(temp->right != NULL){
				temp = temp->right;
			}
			root->val = temp->val;
			root->left = delete_node(root->left, temp->val);	
		}
	}
	return root;
}

struct Node *insert(struct Node *root, int val){
	if (root == NULL){
		return new_node(val); 
	}
	else if(val < root->val){
		root->left = insert(root->left, val);
	}
	else {
		root->right = insert(root->right, val);
	}
	
	return root;
}

void search_node(struct Node *root, int val){
	if (root == NULL){
		printf("Not Found !\n");
		return;
	}
	if (root->val == val){
		printf("Data Found !\n");
	}
	else if(root->val > val){
		search_node(root->left, val);
	}
	else{
		search_node(root->right, val);
	}
}

void prefix(struct Node *curr){
	if (curr != NULL){
		printf("%d ", curr->val);
		prefix(curr->left);
		prefix(curr->right);
	}
}

void infix (struct Node *curr){
	if (curr != NULL){
		infix(curr->left);
		printf("%d ", curr->val);
		infix(curr->right);
	}
}

void postfix(struct Node *curr){
	if (curr != NULL){
		postfix(curr->left);
		postfix(curr->right);
		printf("%d ", curr->val);
	}
}

int main (){
	
	struct Node *root = NULL;
	root = insert(root, 40);
	root = insert(root, 5);
	root = insert(root, 1);
	root = insert(root, 2);
	root = insert(root, 30);
	root = insert(root, 70);
	root = insert(root, 40);
	root = insert(root, 90);

	root = delete_node(root, 2);
	root = delete_node(root, 30);
	root = delete_node(root, 5);
	root = delete_node(root, 40);
	
	
	printf("Prefix: ");
	prefix(root);
	
	printf("\nInfix: ");
	infix(root);
	
	printf("\nPostfix: ");
	postfix(root);
	
	return 0;
}
